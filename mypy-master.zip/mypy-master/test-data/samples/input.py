import typing
name = input('What is your name?\n')
print('Hi, %s.' % name)
