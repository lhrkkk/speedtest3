# Format

In this section you will learn how to:

- Structure your book correctly
- Format your `SUMMARY.md` file
- Configure your book using `book.toml`
- Customize your theme
