# Testing relative links for the print page

When we link to [the first section](../first/nested.md), it should work on
both the print page and the non-print page.

A [fragment link](#some-section) should work.

Link [outside](../../std/foo/bar.html).

![Some image](../images/picture.png)

<a href="../first/markdown.md">HTML Link</a>

<img src="../images/picture.png" alt="raw html">

## Some section
